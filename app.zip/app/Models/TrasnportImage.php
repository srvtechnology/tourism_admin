<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TrasnportImage extends Model
{
    use HasFactory;
    protected $table = 'trasnsport_image';
    protected $guarded = [];
}
