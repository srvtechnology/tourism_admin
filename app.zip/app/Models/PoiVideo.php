<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PoiVideo extends Model
{
    use HasFactory;
    protected $table = 'poi_video';
    protected $guarded = [];
}
